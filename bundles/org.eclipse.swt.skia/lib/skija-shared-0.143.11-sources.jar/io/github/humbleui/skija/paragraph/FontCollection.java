package io.github.humbleui.skija.paragraph;

import org.jetbrains.annotations.*;
import io.github.humbleui.skija.*;
import io.github.humbleui.skija.impl.*;
import java.util.*;

public class FontCollection extends RefCnt {
    static { Library.staticLoad(); }
    
    public FontCollection() {
        this(_nMake());
        Stats.onNativeCall();
    }

    public long getFontManagersCount() {
        try {
            Stats.onNativeCall();
            return _nGetFontManagersCount(_ptr);
        } finally {
            ReferenceUtil.reachabilityFence(this);
        }
    }
    
    public FontCollection setAssetFontManager(FontMgr fontMgr) {
        try {
            Stats.onNativeCall();
            _nSetAssetFontManager(_ptr, Native.getPtr(fontMgr));
            return this;
        } finally {
            ReferenceUtil.reachabilityFence(fontMgr);
        }
    }

    public FontCollection setDynamicFontManager(FontMgr fontMgr) {
        try {
            Stats.onNativeCall();
            _nSetDynamicFontManager(_ptr, Native.getPtr(fontMgr));
            return this;
        } finally {
            ReferenceUtil.reachabilityFence(fontMgr);
        }
    }

    public FontCollection setTestFontManager(FontMgr fontMgr) {
        try {
            Stats.onNativeCall();
            _nSetTestFontManager(_ptr, Native.getPtr(fontMgr));
            return this;
        } finally {
            ReferenceUtil.reachabilityFence(fontMgr);
        }
    }

    public FontCollection setDefaultFontManager(FontMgr fontMgr) {
        return setDefaultFontManager(fontMgr, null);
    }

    public FontCollection setDefaultFontManager(FontMgr fontMgr, String defaultFamilyName) {
        try {
            Stats.onNativeCall();
            _nSetDefaultFontManager(_ptr, Native.getPtr(fontMgr), defaultFamilyName);
            return this;
        } finally {
            ReferenceUtil.reachabilityFence(fontMgr);
        }
    }
    
    @Nullable
    public FontMgr getFallbackManager() {
        try {
            Stats.onNativeCall();
            long ptr = _nGetFallbackManager(_ptr);
            return ptr == 0 ? null : new FontMgr(ptr);
        } finally {
            ReferenceUtil.reachabilityFence(this);
        }
    }

    @NotNull
    public Typeface[] findTypefaces(String[] familyNames, @NotNull FontStyle style) {
        try {
            assert Arrays.stream(familyNames).allMatch(Objects::nonNull) : "Can't findTypefaces with null familyNames elements";
            Stats.onNativeCall();
            long[] ptrs = _nFindTypefaces(_ptr, familyNames, style._value);
            Typeface[] res = new Typeface[ptrs.length];
            for (int i = 0; i < ptrs.length; ++i) {
                res[i] = new Typeface(ptrs[i]);
            }
            return res;
        } finally {
            ReferenceUtil.reachabilityFence(this);
        }
    }

    @Nullable
    public Typeface defaultFallback(int unicode, FontStyle style, String locale) {
        return defaultFallback(unicode, style, locale, null);
    }

    @Nullable
    public Typeface defaultFallback(int unicode, @NotNull FontStyle style, @NotNull String locale, @Nullable FontArguments fontArguments) {
        try {
            assert locale != null : "Can't defaultFallback with locale == null";
            Stats.onNativeCall();
            long ptr = _nDefaultFallbackChar(_ptr, unicode, style._value, locale, fontArguments);
            return ptr == 0 ? null : new Typeface(ptr);
        } finally {
            ReferenceUtil.reachabilityFence(this);
        }
    }

    public Typeface defaultFallback() {
        try {
            Stats.onNativeCall();
            long ptr = _nDefaultFallback(_ptr);
            return ptr == 0 ? null : new Typeface(ptr);
        } finally {
            ReferenceUtil.reachabilityFence(this);
        }
    }

    public FontCollection setEnableFallback(boolean value) {
        Stats.onNativeCall();
        _nSetEnableFallback(_ptr, value);
        return this;
    }

    public ParagraphCache getParagraphCache() {
        try {
            Stats.onNativeCall();
            return new ParagraphCache(this, _nGetParagraphCache(_ptr));
        } finally {
            ReferenceUtil.reachabilityFence(this);
        }
    }

    @ApiStatus.Internal
    public FontCollection(long ptr) {
        super(ptr);
    }

    public static native long   _nMake();
    public static native long   _nGetFontManagersCount(long ptr);
    public static native long   _nSetAssetFontManager(long ptr, long fontManagerPtr);
    public static native long   _nSetDynamicFontManager(long ptr, long fontManagerPtr);
    public static native long   _nSetTestFontManager(long ptr, long fontManagerPtr);
    public static native long   _nSetDefaultFontManager(long ptr, long fontManagerPtr, String defaultFamilyName);
    public static native long   _nGetFallbackManager(long ptr);
    public static native long[] _nFindTypefaces(long ptr, String[] familyNames, int fontStyle);
    public static native long   _nDefaultFallbackChar(long ptr, int unicode, int fontStyle, String locale, FontArguments fontArguments);
    public static native long   _nDefaultFallback(long ptr);
    public static native long   _nSetEnableFallback(long ptr, boolean value);
    public static native long   _nGetParagraphCache(long ptr);
}